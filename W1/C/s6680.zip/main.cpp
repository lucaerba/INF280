#include <iostream>
#include <vector>

using namespace std;

//define filename = "sample-A.1.in"


int main(int argc, char const *argv[])
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    //freopen("sample-C.1.in", "r", stdin);
    //freopen("output.out", "w", stdout);

    //read file
    //1432.23
    // 216.09
    // 1475.09
    // 1327.20
    // 2457.18

    //read the precision of the input reading the first line as string and counting numbers after the point

    string line;
    cin >> line;
    int precision = 0;
    //cout << "line: " << line << endl;
    for (int i = 0; i < line.size(); i++)
    {
        if (line[i] == '.')
        {
            precision = line.size() - i - 1;
            break;
        }
    }

    //read the numbers and compute total
    double total = stod(line);
    //initialize number as first line
    double number = 0;
    //cout << "precision: " << precision << endl;
    while (cin >> number)
    {
        total += number;
    }

    //print the total with the precision
    cout.precision(precision);
    cout << fixed << total << endl;

    return 0;
}
